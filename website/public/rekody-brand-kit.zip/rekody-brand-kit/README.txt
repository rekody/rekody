Rekody brand kit

Use the marks as shipped. Do not alter, recolor, redraw, or add effects to
the r. mark or the rekody. wordmark. Keep the period teal (#20808D) and
attached to the wordmark. Give the mark clear space on all sides.

The wordmark leads. Use the r. mark only where space is tight (avatars,
favicons, the app tile).

Color: white (#FFFFFF) grounds, ink (#0F1717) for words and marks, teal
(#20808D) as the single accent. The teal ramp is for data and waveforms
only. Orange (#FF6B35) means recording and nothing else. Cream (#FBFAF4)
lives only on dark surfaces.

Type: Fraunces for display, JetBrains Mono for labels, Inter for body.
Install them from their sources (see fonts/FONTS.txt). We do not redistribute
the font files.

Product screenshots are approved for editorial and press use as-is. Do not
recrop the pill or restyle the mark inside them.

Contents:
  marks/          the r. mark and the rekody. wordmark, SVG and PNG, light and dark
  app-icon/       the app tile at 1024 / 512 / 256 / 128
  color/          the hex list with roles
  fonts/          font names, sources, and licenses (no font files bundled)
  screenshots/    approved product frames (launch card + gallery)
  guidelines/     the one-page brand guidelines

Questions, interviews, or asset requests: hi@rekody.com
