# Rekody colors

Pure white grounds, ink for words and marks, one teal accent. The teal ramp
is for data and waveforms only. Orange means recording and nothing else.
Cream lives only on dark surfaces.

| Role                          | Hex       |
|-------------------------------|-----------|
| Ground (page)                 | #FFFFFF   |
| Section band                  | #FAFAFA   |
| Ink (words and marks)         | #0F1717   |
| Teal (the accent)             | #20808D   |
| Teal ramp 1 (data/waveforms)  | #2FA3B3   |
| Teal ramp 2 (data/waveforms)  | #4FB8C5   |
| Teal ramp 3 (data/waveforms)  | #7FD4DE   |
| REC orange (recording only)   | #FF6B35   |
| Cream (inside dark only)      | #FBFAF4   |
